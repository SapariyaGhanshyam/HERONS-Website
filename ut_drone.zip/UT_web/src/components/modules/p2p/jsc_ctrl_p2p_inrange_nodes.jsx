import React    from 'react';

import * as js_helpers from '../../../js/js_helpers.js'
import {js_globals} from '../../../js/js_globals.js';
import {EVENTS as js_event} from '../../../js/js_eventList.js'
import {js_eventEmitter} from '../../../js/js_eventEmitter.js'


class ClssCtrlP2PInRangeNodeInfo  extends React.Component {
    constructor(props)
    {
        super(props);
        this.state = {
                m_update: 0
		};

    } 

    render()
    {
        let css_connection_type = "";
        
        
        const v_andruavUnit = this.props.p_unit;
        const v_inrange_node = this.props.p_inrange_node;
        const unit = js_globals.m_andruavUnitList.fn_getUnit(v_inrange_node.partyID);
        let txt_node_name;

        let p2 = v_andruavUnit.getPartyID();
        if (unit!=null)
        {
            p2 = unit.getPartyID();
            txt_node_name = "  " + unit.m_unitName;
        }
        const p1 = v_andruavUnit.getPartyID();
        

        
        return (
            <div key={p1  + p2 + 'irn_1'} className='row css_margin_zero padding_zero  '>

                        <div key={p1 + p2 + 'irn_11'} className="col-6 ">
                            <div key={p1 + p2 + 'irn_111'} className='row css_margin_zero padding_zero '>
                                <p key={p1 + p2 + 'irn_1111'} className="textunit_nowidth user-select-all m-0"><span><small><b>MAC&nbsp; <span className={css_connection_type} ><b>{v_inrange_node.mac}</b></span></b></small></span></p>
                            </div>
                        </div>
                        <div key={p1 + p2 + 'irn_21'} className="col-6 ">
                            <div key={p1 + p2 + 'irn_212'} className='row css_margin_zero padding_zero '>
                                <p key={p1 + p2 + 'irn_2121'} className="textunit_nowidth user-select-all m-0"><span><small><b>UNIT&nbsp; <span className='text-success'>{txt_node_name}</span><span className='text-warning' ><b>: {js_helpers.fn_getTimeDiffDetails_Shortest (v_inrange_node.last_time/1000000)}</b></span></b></small></span></p>
                            </div>
                        </div>
            </div>
            
        );
    }

    }

export class CLASS_CTRL_P2P_IN_RANGE_NODEs extends React.Component {

    constructor(props)
    {
        super(props);
        this.state = {
                m_update: 0
		};

        js_eventEmitter.fn_subscribe (js_event.EE_unitP2PUpdated,this,this.fn_unitUpdated);
    }


    componentWillUnmount () {
        js_eventEmitter.fn_unsubscribe (js_event.EE_unitP2PUpdated,this);
    }

    componentDidMount () 
    {
        this.m_flag_mounted = true;
    }

    fn_unitUpdated (p_me,p_andruavUnit)
    {
        if (p_me.props.p_unit.getPartyID() !== p_andruavUnit.getPartyID()) return ;
        if (p_me.m_flag_mounted === false)return ;
        p_me.setState({'m_update': p_me.state.m_update +1});
    }


    render () 
    {
        const  v_andruavUnit = this.props.p_unit;
        let v_units = [];
        Object.entries(v_andruavUnit.m_P2P.m_detected_node).forEach(([partyID, inrange_node]) => {
            
            v_units.push( 
                    <ClssCtrlP2PInRangeNodeInfo key={v_andruavUnit.partID+partyID+'RANGE_NODE_INFO1'}  p_unit={v_andruavUnit} p_inrange_node={inrange_node} />
                );
        });
        
        let rendered=[];
        if (v_units.length === 0)
        {
            rendered.push (
                <div key={v_andruavUnit.partID+'RANGE_NODE_INFO00'} className='row css_margin_zero padding_zero border-top border-secondary' >
                <div className='col-12 user-select-none textunit_nowidth text-danger'>No&nbsp;Pinging&nbsp;Nodes</div>
                </div>);
        }
        else
        {
            rendered.push (   <div key={v_andruavUnit.partID+'RANGE_NODE_INFO00'} className='row css_margin_zero padding_zero border-top border-secondary' >
                <div className='col-12 user-select-none textunit_nowidth text-info'><b>&nbsp;Pinging&nbsp;Nodes</b></div>
                </div>);
        }
        
        
        return (
            <div key={v_andruavUnit.partID+'RANGE_NODE_INFO'} >{rendered}{v_units}</div>
        )
    }
}
