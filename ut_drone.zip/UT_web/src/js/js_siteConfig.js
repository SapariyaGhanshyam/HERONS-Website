/**
 * 
 * SITE Configuration File
 * 
 * Communication Server
 */


// Default Configuration
export let CONST_TEST_MODE = true;
export let CONST_PROD_MODE_IP = 'airgap.droneengage.com';
export let CONST_PROD_MODE_PORT = '19408';
export let CONST_TEST_MODE_IP = '127.0.0.1';
export let CONST_TEST_MODE_PORT = '19408';
export let CONST_TEST_MODE_ENABLE_LOG = false;
export let CONST_TITLE = 'LiveOps-Cloud';
export let CONST_TITLE_2 = "Unbemannt Technologies"

/**
 * Links that are used in Header
 */
export let CONST_HOME_URL = "https://www.invenco-ai.in/";
export let CONST_MANUAL_URL = "https://www.invenco-ai.in/";
export let CONST_FAQ_URL = "https://www.invenco-ai.in/";
export let CONST_CONTACT_URL = "https://www.invenco-ai.in/";
export let CONST_ANDRUAV_URL = "https://www.invenco-ai.in/";
export let CONST_ANDRUAV_URL_ENABLE = true;
export let CONST_ACCOUNT_URL_ENABLE = true;

// CHOOSE YOUR MAP SOURCE
export let CONST_MAP_LEAFLET_URL = "https://api.mapbox.com/styles/v1/mapbox/satellite-v9/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiaHNhYWQiLCJhIjoiY2tqZnIwNXRuMndvdTJ4cnV0ODQ4djZ3NiJ9.LKojA3YMrG34L93jRThEGQ";
//export let CONST_MAP_LEAFLET_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
//export let CONST_MAP_LEAFLET_URL = "https://airgap.local:88/sat_{x}_{y}_{z}.png"; // LOCAL MAP



/**
 * Location of GCS are not sent over network. Only The existence of connected GCS are shared.
 */
export let CONST_DONT_BROADCAST_TO_GCSs = false;
export let CONST_DONT_BROADCAST_GCS_LOCATION = false;



export let CONST_MODULE_VERSIONS = {
        
    };


/**
 * This is for disable features.
 * If a feature is not explicitly mentioned or has a value of true, it is considered to be enabled.
 */
export let CONST_FEATURE = {
    DISABLE_UNIT_NAMING: false,
    DISABLE_UDPPROXY_UPDATE: false,
    DISABLE_SWARM: false,
    DISABLE_SWARM_DESTINATION_PONTS: false,
    DISABLE_P2P: false,
    DISABLE_SDR: false,
    DISABLE_GPIO: false,
    DISABLE_VOICE: false,
    DISABLE_TRACKING: false,
    DISABLE_TRACKING_AI: false,
    DISABLE_EXPERIMENTAL: true,
    DISABLE_VERSION_NOTIFICATION: true
};

/**
 * Notice yoy cannot define new languages here.
 * Only languages with locale files can be used.
 */
export let CONST_LANGUAGE = {
  ENABLED_LANGUAGES: [
    { code: 'en', label: 'English', className: '' },
    { code: 'ar', label: 'عربى', className: 'rtl' },
    { code: 'es', label: 'Español', className: '' },
    { code: 'ru', label: 'Русский', className: '' }
  ],
  DEFAULT_LANGUAGE: 'en'
};

/**
 * WEBRTC Video Streaming Settings
 */
export let CONST_ICE_SERVERS = [
    { urls: 'turn:cloud.ardupilot.org', credential: '1234', username: 'andruav_ap' },
    { urls: "stun:stun1.l.google.com:19302" },
];



/**
 * This function load overrides values from config.json in public folder.
 */
function loadConfigSync() {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/config.json', false); // Synchronous request
        xhr.send(null);

        if (xhr.status === 200) {
            let jsonString = xhr.responseText;

            // Remove multi-line comments
            jsonString = jsonString.replace(/\/\*[\s\S]*?\*\//g, '');

            // Remove single-line comments
            jsonString = jsonString.replace(/(^|\s)\/\/.*/g, '');

            const data = JSON.parse(jsonString);

            // Update the exported constants
            if (data.CONST_TEST_MODE !== undefined) CONST_TEST_MODE = data.CONST_TEST_MODE;
            if (data.CONST_PROD_MODE_IP !== undefined) CONST_PROD_MODE_IP = data.CONST_PROD_MODE_IP;
            if (data.CONST_PROD_MODE_PORT !== undefined) CONST_PROD_MODE_PORT = data.CONST_PROD_MODE_PORT;

            if (data.CONST_TEST_MODE_IP !== undefined) CONST_TEST_MODE_IP = data.CONST_TEST_MODE_IP;
            if (data.CONST_TEST_MODE_PORT !== undefined) CONST_TEST_MODE_PORT = data.CONST_TEST_MODE_PORT;


            if (data.CONST_ANDRUAV_URL_ENABLE !== undefined) CONST_ANDRUAV_URL_ENABLE = data.CONST_ANDRUAV_URL_ENABLE;
            if (data.CONST_ACCOUNT_URL_ENABLE !== undefined) CONST_ACCOUNT_URL_ENABLE = data.CONST_ACCOUNT_URL_ENABLE;
            
            if (data.CONST_MAP_LEAFLET_URL !== undefined) CONST_MAP_LEAFLET_URL = data.CONST_MAP_LEAFLET_URL;
            if (data.CONST_DONT_BROADCAST_TO_GCSs !== undefined) CONST_DONT_BROADCAST_TO_GCSs = data.CONST_DONT_BROADCAST_TO_GCSs;
            if (data.CONST_DONT_BROADCAST_GCS_LOCATION !== undefined) CONST_DONT_BROADCAST_GCS_LOCATION = data.CONST_DONT_BROADCAST_GCS_LOCATION;

            if (data.CONST_FEATURE !== undefined) CONST_FEATURE = { ...CONST_FEATURE, ...data.CONST_FEATURE };
            if (data.CONST_ICE_SERVERS !== undefined) CONST_ICE_SERVERS = data.CONST_ICE_SERVERS;

            if (data.CONST_MODULE_VERSIONS !== undefined) CONST_MODULE_VERSIONS = { ...CONST_MODULE_VERSIONS, ...data.CONST_MODULE_VERSIONS};

            if (data.CONST_LANGUAGE !== undefined) CONST_LANGUAGE = { ...CONST_LANGUAGE, ...data.CONST_LANGUAGE};
        } else {
            console.error('Error loading config:', xhr.status);
        }
    } catch (error) {
        console.error('Error loading config:', error);
    }
}

loadConfigSync(); // Load the config synchronously