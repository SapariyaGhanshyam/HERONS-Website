export default class C_GUI_READING_VALUE {
    constructor() {
        this.css = '';
        this.value = '';
        this.unit = '';
    }

}